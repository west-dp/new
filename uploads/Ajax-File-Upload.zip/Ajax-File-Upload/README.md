Simple File Upload with PHP & Ajax
================

Simple File Upload with Ajax 

This is a demo code to upload file using PHP and Ajax made for article on Techstream <a href="http://techstream.org/Web-Development/PHP/Simple-File-Upload-with-Ajax">Simple File Upload with Ajax</a>.

Credits
-------

<ul>
  <li><strong>Fonts by <a href="http://www.fontsquirrel.com">Font Squirrel </a></strong> : Source Sans Pro by Adobe released in SIL Open Font License v1.10. See <a href="http://www.fontsquirrel.com/license/source-sans-pro">Licence</a> for details.</li>
  <li><strong>White Board Framework</strong> : <a href="https://github.com/anushbmx/whiteboard/">White Board</a> by <a href="http://twitter.com/anushbmx">anushbmx</a> &amp; <a href="http://twitter.com/supersolanki">supersolanki</a></li>
  <li><strong>Glyph Icons by Font <a href="http://fontawesome.io/license/">Awesome Icons</a></strong> : Font Awesome is fully open source project under SIL OFL 1.1 License. </li>
</ul>

